package com.simplilearn.petadoption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetadoptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
